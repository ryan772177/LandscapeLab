"""Bake a CPU-queryable SURFACE TYPE lookup from the layer weightmap.

    python scripts/bake_surface_lookup.py
    python scripts/bake_surface_lookup.py --write

PHASE2_PLAN unit 11. "What am I standing on?" -- for footstep audio, movement
modifiers, VFX, and anything else that needs the surface without asking the
renderer.

** IT READS THE SAME DECLARATION THE MATERIAL READS. ** `textures/<biome>_weights.png`
is baked once by `make_layer_weightmap.py` and sampled by the landscape
material; this samples that same file. Non-negotiable 19: a second definition of
"where the rock is" would drift from the first silently, and the two would
disagree in a way no single check could see.

** DO NOT GET THIS BY PAINTING LANDSCAPE LAYERS. ** That forks the surface
definition -- the painted layers and the baked weightmap become two sources for
one physical fact, which is the same rule from the other direction.

WHAT IT PRODUCES
----------------
Two arrays at the weightmap's own resolution, written as one PNG:

    R  DOMINANT LAYER INDEX  (0..N-1, the recipe's layer order)
    G  DOMINANCE             (0..255) how far the winner leads the runner-up
    B  0, DECLARED INERT     -- non-negotiable 21: a channel nobody assigned
                                carries whatever was there and reads like data

** DOMINANCE IS NOT CONFIDENCE IN THE BAKE, IT IS BLEND DEPTH IN THE WORLD. **
The material BLENDS layers; it does not choose one. A cell at dominance 4 is
genuinely half rock and half grass, and a consumer that wants a single answer
there is asking a question the world does not have. Consumers should treat low
dominance as "on a boundary" rather than as "the lookup is unsure".

WHAT THIS CANNOT DO, from PHASE2_PLAN unit 11 verbatim
------------------------------------------------------
Per-surface WALKABILITY is not achievable this way. `IsWalkable` reads
`HitComponent->GetWalkableSlopeOverride()`, which is a PER-COMPONENT override,
and one landscape component here is 254 m square. "Scree is unwalkable" must be
gameplay logic on top of this query, never a landscape setting.
"""
import argparse
import hashlib
import io
import json
import os
import sys

import numpy as np
from PIL import Image

Image.MAX_IMAGE_PIXELS = None

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--recipe", default="recipes/alpine_8k.json")
    ap.add_argument("--samples", type=int, default=20000,
                    help="points for the positive control")
    ap.add_argument("--seed", type=int, default=20260827)
    ap.add_argument("--write", action="store_true")
    args = ap.parse_args()

    rp = os.path.join(REPO_ROOT, args.recipe)
    rec = json.loads(io.open(rp, encoding="utf-8").read())
    layers = rec["material"]["layers"]
    biome = rec["biome_id"]

    wpath = os.path.join(REPO_ROOT, "textures", "%s_weights.png" % biome)
    if not os.path.exists(wpath):
        sys.exit("REFUSE: no weightmap at %s. It is baked by "
                 "make_layer_weightmap and is the material's own source; "
                 "this must not invent one." % wpath)

    # v1.26 (2026-09-12): FOUR stored channels plus a shader REMAINDER.
    # `mask_plan` is IMPORTED from the material builder, not restated --
    # this file and the shader must agree about which channel is which
    # layer, and two copies of that mapping would disagree silently: the
    # shader would paint scree where the footstep audio played grass,
    # with nothing to compare them against (NN24, and NN19 again).
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import make_landscape_material as _mlm      # noqa: E402

    W = np.asarray(Image.open(wpath).convert("RGBA")).astype(np.int16)
    h, w, _ = W.shape
    try:
        direct, has_remainder = _mlm.mask_plan(len(layers))
    except _mlm.TexturePlanError as e:
        sys.exit("REFUSE: %s" % e)

    W = W[:, :, :direct]
    if has_remainder:
        # DERIVED EXACTLY AS THE SHADER DERIVES IT: 1 - sum(stored),
        # clamped at 0. Storing it instead would be a fifth number
        # obliged to agree with four others.
        rem = np.clip(255 - W.sum(axis=2), 0, 255).astype(np.int16)
        W = np.concatenate([W, rem[:, :, None]], axis=2)
    if W.shape[2] != len(layers):
        sys.exit("REFUSE: built %d mask channels for %d layers"
                 % (W.shape[2], len(layers)))

    print("recipe       %s   biome %s" % (args.recipe, biome))
    print("weightmap    %s   %d x %d" % (os.path.relpath(wpath, REPO_ROOT),
                                         w, h))
    print("layers       %s" % ", ".join(
        "%d=%s(%s)" % (i, l["name"], l.get("surface"))
        for i, l in enumerate(layers)))
    print()

    order = np.argsort(W, axis=2)
    dominant = order[:, :, -1].astype(np.uint8)
    top = np.take_along_axis(W, order[:, :, -1:], axis=2)[:, :, 0]
    second = np.take_along_axis(W, order[:, :, -2:-1], axis=2)[:, :, 0]
    dominance = np.clip(top - second, 0, 255).astype(np.uint8)

    print("DOMINANT LAYER, share of the map:")
    for i, l in enumerate(layers):
        frac = float((dominant == i).mean())
        print("  %d %-8s %8.4f%%   (%s)" % (i, l["name"], 100.0 * frac,
                                            l.get("surface")))
    print()
    print("DOMINANCE -- how far the winner leads the runner-up:")
    for q in (10, 50, 90):
        print("  p%-3d %6.1f" % (q, float(np.percentile(dominance, q))))
    boundary = float((dominance < 16).mean())
    print("  under 16 (a genuine blend, not an unsure lookup): %.2f%%"
          % (100.0 * boundary))
    print()

    # ---- POSITIVE CONTROL -------------------------------------------------
    # Re-derive the answer at N random points STRAIGHT FROM THE WEIGHTMAP, by
    # code that did not build the arrays. A bake that agrees with itself proves
    # nothing; this proves the arrays say what the source says.
    rng = np.random.default_rng(args.seed)
    ys = rng.integers(0, h, size=args.samples)
    xs = rng.integers(0, w, size=args.samples)
    direct = np.argmax(W[ys, xs, :], axis=1).astype(np.uint8)
    baked = dominant[ys, xs]
    agree = int((direct == baked).sum())
    print("POSITIVE CONTROL  %d random points, re-derived from the weightmap"
          % args.samples)
    print("  agree           %d of %d  (%.4f%%)"
          % (agree, args.samples, 100.0 * agree / args.samples))

    # ---- NEGATIVE CONTROL -------------------------------------------------
    # Shift the lookup by one row and it must STOP agreeing. Without this,
    # 100% agreement is also what a comparison against itself returns.
    shifted = np.roll(dominant, 1, axis=0)[ys, xs]
    dis = int((direct != shifted).sum())
    print("NEGATIVE CONTROL  the same lookup shifted one row")
    print("  disagree        %d of %d  (%.2f%%)  -- must be well above 0"
          % (dis, args.samples, 100.0 * dis / args.samples))
    print()

    ok = (agree == args.samples) and (dis > args.samples * 0.01)
    if not ok:
        print("REFUSE: controls did not behave. agree must be 100%% and the "
              "shifted lookup must disagree materially.")
        return 3

    out = np.zeros((h, w, 3), dtype=np.uint8)
    out[:, :, 0] = dominant
    out[:, :, 1] = dominance
    # B is DECLARED INERT and written zero, and this line is the declaration
    # (non-negotiable 21). A channel nobody assigns carries whatever the
    # allocator left, reads like data, and is sampled by something eventually.
    out[:, :, 2] = 0

    dst = os.path.join(REPO_ROOT, "textures", "%s_surface.png" % biome)
    if not args.write:
        print("REPORT ONLY -- nothing written. Re-run with --write to bake "
              "%s" % os.path.relpath(dst, REPO_ROOT))
        return 0

    Image.fromarray(out, mode="RGB").save(dst)
    back = np.asarray(Image.open(dst).convert("RGB"))
    if not np.array_equal(back[:, :, 0], dominant):
        sys.exit("REFUSE: wrote the lookup and read back a different R "
                 "channel. PNG is lossless, so this is a real defect.")
    if back[:, :, 2].any():
        sys.exit("REFUSE: the inert B channel read back non-zero.")

    sha = hashlib.sha256(io.open(dst, "rb").read()).hexdigest()
    side = os.path.join(REPO_ROOT, "textures",
                        "%s_surface.json" % biome)
    io.open(side, "w", encoding="utf-8", newline="\n").write(json.dumps({
        "_what": "CPU surface-type lookup baked from the layer weightmap the "
                 "landscape material samples. R = dominant layer index in "
                 "recipe order, G = dominance (winner minus runner-up), "
                 "B = DECLARED INERT, written zero.",
        "_produced_by": "scripts/bake_surface_lookup.py",
        "_recipe": args.recipe,
        "_source_weightmap": os.path.relpath(wpath, REPO_ROOT).replace(
            "\\", "/"),
        "_walkability_is_NOT_available_here": (
            "IsWalkable reads HitComponent->GetWalkableSlopeOverride(), a "
            "PER-COMPONENT override, and one landscape component here is 254 m "
            "square. 'Scree is unwalkable' must be gameplay logic on top of "
            "this query, never a landscape setting."),
        "layers": [{"index": i, "name": l["name"],
                    "surface": l.get("surface")} for i, l in enumerate(layers)],
        "size": [w, h],
        "sha256": sha,
        "dominant_share": {l["name"]: round(float((dominant == i).mean()), 6)
                           for i, l in enumerate(layers)},
        "blend_boundary_fraction": round(boundary, 6),
    }, indent=1) + "\n")

    print("wrote %s  (%.1f MB)" % (os.path.relpath(dst, REPO_ROOT),
                                   os.path.getsize(dst) / 1048576.0))
    print("wrote %s  sha %s" % (os.path.relpath(side, REPO_ROOT), sha[:12]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
