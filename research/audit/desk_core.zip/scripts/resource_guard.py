"""resource_guard.py — RAM check and a mutual-exclusion lock for heavy work.

WHY THIS EXISTS
This machine has 15.4 GB of RAM and an integrated GPU, and the project
has already lost the editor twice in one session: once to a GPU TDR
(DXGI_ERROR_DEVICE_HUNG, LESSONS.md 23.12) and once to a
"World Memory Leaks" assert during a map transition (23.13). Neither was
caused by memory, but both happened while several heavy things were in
flight, and the recovery cost more than the check would have.

TWO GUARANTEES, and they are separate concerns deliberately.

  1. REPORT THE MEMORY BEFORE STARTING. A run that begins with 1.5 GB
     free and dies in the middle is indistinguishable, afterwards, from
     a run that had a logic bug. Logging the number at the top makes the
     post-mortem a lookup instead of an argument.

  2. RUN HEAVY OPERATIONS ONE AT A TIME. Landscape rebuild, foliage
     regeneration and lighting builds all drive the same editor through
     the same UDP port. Two at once do not merely contend for RAM -- they
     interleave mutations in the live editor, which is the failure mode
     no amount of memory fixes.

WHY WARN AND NOT REFUSE (a deliberate ruling, 2026-08-02)
Low memory is a RISK, not a fault. Refusing below a threshold would mean
that on the documented hardware -- where an open editor alone leaves
about 1.8 GB free -- every script would refuse and the pipeline would be
unusable. So the memory check WARNS, loudly, with the number. The LOCK,
by contrast, REFUSES: two concurrent editor mutations is never something
the caller wanted.

The lock is advisory and cooperative: it only constrains scripts that
call into it. It is not a defence against someone driving the editor by
hand at the same time, and it does not pretend to be.

Stale locks are handled by liveness, not by age: a lock file naming a PID
that no longer exists is reclaimed, because the alternative -- a timeout
-- either strands a genuinely long run or leaves a dead lock in place.
"""

from __future__ import annotations

import json
import os
import sys
import time

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOCK_PATH = os.path.join(REPO_ROOT, ".heavy-op.lock")

# Warn below this. Chosen against the documented hardware: an editor with
# the alpine level open sits around 6.5 GB, leaving ~8 GB, and the runs
# that have actually hurt were the ones starting near 2 GB.
WARN_FREE_GB = 4.0


def available_gb():
    """(available_gb, total_gb) or (None, None) if it cannot be read.

    Returns None rather than 0 on failure. A memory check that reports
    "0 GB free" when it simply could not look would fire its own warning
    every run and be ignored within a day -- section 2.10, "I could not
    look" is not "it is absent".
    """
    try:
        import ctypes

        class _MS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong),
                        ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong),
                        ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong),
                        ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong),
                        ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

        st = _MS()
        st.dwLength = ctypes.sizeof(_MS)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)):
            return None, None
        return (st.ullAvailPhys / (1024.0 ** 3),
                st.ullTotalPhys / (1024.0 ** 3))
    except Exception:
        return None, None


def check_memory(label, warn_gb=WARN_FREE_GB, stream=None):
    """Print the memory situation. Returns True if it looks comfortable.

    Never raises and never exits: this is an instrument, not a gate.
    """
    out = stream or sys.stdout
    avail, total = available_gb()
    if avail is None:
        out.write("  RAM: COULD NOT BE READ -- proceeding without the "
                  "check. This is not 'memory is fine'.\n")
        return True
    out.write("  RAM: {0:.1f} GB available of {1:.1f} GB "
              "(warn below {2:.1f})\n".format(avail, total, warn_gb))
    if avail < warn_gb:
        out.write("  *** LOW MEMORY WARNING ***  {0} is a heavy operation "
                  "and only {1:.1f} GB is free.\n".format(label, avail))
        out.write("      Close the browser, or any second editor, before "
                  "blaming the result. Proceeding anyway -- low memory is "
                  "a risk, not a fault.\n")
        return False
    return True


def _pid_alive(pid):
    """True if a process with this PID exists. Unknown -> True.

    Erring toward 'alive' keeps a lock rather than stealing one. A lock
    wrongly kept costs a re-run; a lock wrongly stolen costs two scripts
    mutating one editor at once, which is the thing this exists to stop.
    """
    if pid <= 0:
        return False
    try:
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))
        if not h:
            return ctypes.windll.kernel32.GetLastError() != 87  # not "no such"
        code = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(h)
        return code.value == 259  # STILL_ACTIVE
    except Exception:
        return True


def _read_lock():
    try:
        with open(LOCK_PATH, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


class HeavyOp(object):
    """Context manager: one heavy editor operation at a time.

        with HeavyOp("foliage placement") as ok:
            if not ok:
                return 8
            ...

    Enter prints the memory line and takes the lock. It returns False --
    rather than raising -- if another heavy operation holds it, so the
    caller chooses its own exit code and message.
    """

    def __init__(self, label, warn_gb=WARN_FREE_GB):
        self.label = label
        self.warn_gb = warn_gb
        self.held = False
        self.blocker = None

    def __enter__(self):
        print("--- resource guard: {0} ---".format(self.label))
        check_memory(self.label, self.warn_gb)
        other = _read_lock()
        if other and _pid_alive(int(other.get("pid", -1))):
            self.blocker = other
            print("  REFUSE: '{0}' (pid {1}) has held the heavy-operation "
                  "lock since {2}.".format(
                      other.get("label", "?"), other.get("pid", "?"),
                      other.get("started", "?")))
            print("  Heavy operations drive the SAME editor through the "
                  "same port; running two interleaves mutations in live "
                  "state. Wait for it, or delete {0} if you are certain "
                  "it is dead.".format(LOCK_PATH))
            return False
        if other:
            print("  reclaiming a lock left by dead pid {0} ({1})".format(
                other.get("pid"), other.get("label")))
        try:
            with open(LOCK_PATH, "w", encoding="utf-8") as fh:
                json.dump({"pid": os.getpid(), "label": self.label,
                           "started": time.strftime("%Y-%m-%d %H:%M:%S")}, fh)
            self.held = True
            print("  lock taken (pid {0})".format(os.getpid()))
        except OSError as exc:
            # Cannot take the lock -> proceed rather than block the
            # pipeline on a bookkeeping failure, but say so.
            print("  NOTE: could not write {0} ({1}); running WITHOUT "
                  "mutual exclusion.".format(LOCK_PATH, exc))
        return True

    def __exit__(self, *exc):
        if not self.held:
            return False
        try:
            cur = _read_lock()
            if cur and int(cur.get("pid", -1)) == os.getpid():
                os.remove(LOCK_PATH)
        except OSError:
            pass
        return False


if __name__ == "__main__":
    avail, total = available_gb()
    print("REPO_ROOT : {0}".format(REPO_ROOT))
    print("lock file : {0}".format(LOCK_PATH))
    if avail is None:
        print("memory    : UNREADABLE")
    else:
        print("memory    : {0:.1f} GB free of {1:.1f} GB".format(avail, total))
    cur = _read_lock()
    if cur:
        print("held by   : {0} (pid {1}, since {2}) alive={3}".format(
            cur.get("label"), cur.get("pid"), cur.get("started"),
            _pid_alive(int(cur.get("pid", -1)))))
    else:
        print("held by   : nobody")
