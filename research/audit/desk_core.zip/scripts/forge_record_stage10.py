"""forge_record_stage10.py — fold a stage-10 run's measurements back into the
forge's own records.

    python scripts/ue_exec.py scripts/forge_scale_payload.txt ... > s10.txt
    python scripts/forge_record_stage10.py --asset wood_stack --from s10.txt

WHY THIS EXISTS.
Stage 10 runs in a live editor through `ue_exec`, so its result comes back on
stdout and lands NOWHERE. Until 2026-08-30 the only way to record it was to
read the JSON and retype the numbers into `forge_report.json` and `ASSETS.md`.

That is precisely the defect stage 8 shipped with: a value computed, printed,
and written to no file, with a human quietly doing the write. It went unnoticed
for a whole asset because the church's row had been typed by hand. Repeating
the pattern one stage later, having just fixed it, would be the same mistake
twice -- which the operating loop calls a process failure, not an accident.

WHAT IT REFUSES
  * a payload that reported ok:false -- a failed stage 10 is not a record
  * a report whose orientation gate did not pass
  * an asset with no forge_report.json to fold into

It writes the FULL payload output, not a summary, because the summary is what
drifts.
"""
from __future__ import annotations

import argparse
import io
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootstrap  # noqa: E402

REPO = bootstrap.REPO_ROOT
OUTROOT = os.path.join(REPO, "_verify", "20260830_forge")
ASSETS_MD = os.path.join(REPO, "ASSETS.md")


def extract(text):
    """Pull the payload's JSON out of a ue_exec transcript.

    ue_exec prints discovery lines first, then the payload's `__LL__`-marked
    JSON, then a timing line. Parse the LAST balanced JSON object rather than
    assuming the whole file is JSON.
    """
    marker = "__LL__"
    if marker in text:
        text = text.split(marker)[-1]
    start = text.find("{")
    if start < 0:
        raise ValueError("no JSON object in the transcript")
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return json.loads(text[start:i + 1])
    raise ValueError("unbalanced JSON in the transcript")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--asset", required=True)
    ap.add_argument("--from", dest="src", required=True,
                    help="file holding the ue_exec transcript or raw JSON")
    ap.add_argument("--frames", nargs="*", default=[],
                    help="evidence frames to cite in the ASSETS.md row")
    args = ap.parse_args(argv)

    with io.open(args.src, encoding="utf-8", errors="replace") as fh:
        s10 = extract(fh.read())

    outdir = os.path.join(OUTROOT, args.asset)
    rep_p = os.path.join(outdir, "forge_report.json")
    if not os.path.exists(rep_p):
        print("REFUSE: no forge_report.json at %s" % rep_p)
        return 2

    if not s10.get("ok"):
        print("REFUSE: the stage-10 payload reported ok=false. A failed run "
              "is not a record.\n  error: %s" % str(s10.get("error"))[:300])
        return 2
    if not s10.get("orientation_ok"):
        print("REFUSE: orientation_ok is not true. The orientation gate is "
              "the whole reason stage 10 exists -- a scale hit on the wrong "
              "axis reports a PERFECT score. Nothing is recorded.")
        return 2

    with io.open(rep_p, encoding="utf-8") as fh:
        rep = json.load(fh)
    rep["stage10"] = s10
    rep["stages"]["10_scale"] = (
        "ok -- %s cm top against a %s cm target (error %s cm), orientation "
        "gate PASSED, level %s"
        % (s10.get("top_cm"), s10.get("target_cm"), s10.get("height_error_cm"),
           s10.get("level")))
    if args.frames:
        rep["stage10_frames"] = list(args.frames)
    with io.open(rep_p, "w", encoding="utf-8") as fh:
        json.dump(rep, fh, indent=1)
    print("forge_report.json <- stage10 (%d keys)" % len(s10))

    # ---- ASSETS.md: flip the "verified in engine" column ------------------
    name = rep["name"]
    cite = ", ".join("`%s`" % f for f in args.frames) if args.frames else ""
    verdict = ("YES — %s cm top vs a %s cm target (error %s cm), footprint "
               "%s cm, orientation gate PASSED, %s tris in engine%s"
               % (s10.get("top_cm"), s10.get("target_cm"),
                  s10.get("height_error_cm"), s10.get("footprint_cm"),
                  s10.get("mesh_tris"),
                  (" — " + cite) if cite else ""))

    with io.open(ASSETS_MD, encoding="utf-8", newline="") as fh:
        raw = fh.read()
    nl = "\r\n" if "\r\n" in raw else "\n"
    lines = raw.replace("\r\n", "\n").split("\n")
    key = "/" + name + "`"
    hit = [i for i, ln in enumerate(lines)
           if ln.startswith("|") and key in ln]
    if len(hit) != 1:
        print("REFUSE: expected exactly 1 ASSETS.md row for %s, found %d. "
              "Not editing a table I cannot identify a row in."
              % (name, len(hit)))
        return 2
    i = hit[0]
    cells = lines[i].split("|")
    # a markdown row is  '' | c1 | c2 | ... | cN | ''  -> last cell is [-2]
    cells[-2] = " " + verdict + " "
    lines[i] = "|".join(cells)
    with io.open(ASSETS_MD, "w", encoding="utf-8", newline="") as fh:
        fh.write(nl.join(lines))
    print("ASSETS.md      <- verified-in-engine for %s" % name)
    print("  " + verdict)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
