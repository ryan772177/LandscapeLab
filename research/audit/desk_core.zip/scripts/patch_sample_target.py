"""patch_sample_target.py — edit a sample project's *.Target.cs so its modules
can be rebuilt against 5.8.

OPERATOR-RULED. Standing rule 1 says never write outside this repo; Ryan
authorised this edit specifically. Rule 4 protects .uproject/.uasset/.umap --
a .Target.cs is a C# BUILD SCRIPT and is not in that set, so the constraint
here is the operator ruling, not the file type.

WHY TWO MODES
-------------
UBT refused AncientGameEditor with:

    AncientGameEditor modifies the values of properties:
      [ UnreachableCodeWarningLevel: Off != Error,
        ReturnTypeWarningLevel:      Off != Error,
        DanglingWarningLevel:        Off != Error ]

The target declares `DefaultBuildSettings = BuildSettingsVersion.V6`, which
defaults those three Off; UE 5.8 defaults them Error. Under an INSTALLED
engine every target shares one build environment, so a target that changes a
global compiler setting is refused.

  --mode unique   adds `BuildEnvironment = TargetBuildEnvironment.Unique;`
                  UBT's headline suggestion. EXPECTED TO FAIL on an installed
                  engine, which cannot rebuild engine binaries with different
                  settings -- tried anyway because a 1-second refusal is
                  cheaper than my theory about it.
  --mode v7       raises DefaultBuildSettings to V7 so the target adopts 5.8's
                  defaults and stops modifying them, keeping the SHARED
                  environment. UBT's own [Upgrade] block names this route.

Backs the original into THIS repo before touching anything, so the edit is
reversible from here even if the sample copy is deleted -- which has already
happened once this session.
"""
from __future__ import annotations

import argparse
import io
import os
import shutil
import sys

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKUPS = os.path.join(REPO, "research", "census", "config_backups")

TARGETS = {
    "ValleyOfTheAncient": r"C:\ProgramData\Epic\EpicGamesLauncher\VaultCache\AncientGame_5.7\data\Source\AncientGameEditor.Target.cs",
}

UNIQUE_LINE = "\t\tBuildEnvironment = TargetBuildEnvironment.Unique;\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True, choices=sorted(TARGETS))
    ap.add_argument("--mode", choices=("unique", "v7"), required=True)
    ap.add_argument("--revert", action="store_true")
    a = ap.parse_args()

    path = TARGETS[a.project]
    if not os.path.exists(path):
        raise SystemExit("REFUSE: no Target.cs at %s" % path)
    os.makedirs(BACKUPS, exist_ok=True)
    backup = os.path.join(BACKUPS,
                          "%s__%s.orig" % (a.project, os.path.basename(path)))

    if a.revert:
        if not os.path.exists(backup):
            raise SystemExit("REFUSE: no backup at %s" % backup)
        shutil.copy2(backup, path)
        print("reverted %s" % path)
        return 0

    # ONCE, and never overwritten: a backup taken after an edit preserves the
    # edit, not the original.
    if not os.path.exists(backup):
        shutil.copy2(path, backup)
        print("backed up -> %s" % os.path.relpath(backup, REPO))

    # Always start from the ORIGINAL, so modes do not stack on each other.
    src = io.open(backup, encoding="utf-8").read()

    if a.mode == "unique":
        if "TargetBuildEnvironment.Unique" in src:
            print("already unique")
        else:
            anchor = "ExtraModuleNames.AddRange"
            i = src.find(anchor)
            if i < 0:
                raise SystemExit("REFUSE: anchor %r not found" % anchor)
            line_start = src.rfind("\n", 0, i) + 1
            src = src[:line_start] + UNIQUE_LINE + src[line_start:]
    else:
        if "BuildSettingsVersion.V6" not in src:
            raise SystemExit("REFUSE: expected BuildSettingsVersion.V6 and "
                             "did not find it -- not guessing at the edit")
        src = src.replace("BuildSettingsVersion.V6", "BuildSettingsVersion.V7")

    io.open(path, "w", encoding="utf-8", newline="").write(src)
    after = io.open(path, encoding="utf-8").read()
    ok = ("TargetBuildEnvironment.Unique" in after if a.mode == "unique"
          else "BuildSettingsVersion.V7" in after)
    print("mode %s applied to %s" % (a.mode, path))
    print("read back: %s" % ok)
    print("--- file now ---")
    for ln in after.splitlines():
        if any(k in ln for k in ("BuildSettings", "BuildEnvironment",
                                 "IncludeOrder", "ExtraModule")):
            print("  " + ln.strip())
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
