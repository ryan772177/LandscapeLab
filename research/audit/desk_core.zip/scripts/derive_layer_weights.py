"""derive_layer_weights.py — eight layer weights, DERIVED, never painted.

Brief 3 Task 2 (BRIEF 3 sec 3.4-3.6). Inputs: the adopted heightmap, the
Gaea flow/deposition exports, and the placed foliage instance JSONs.
Output: two RGBA weight PNGs (weights sum to 1 everywhere) plus a sidecar
recording every layer's formula, inputs, thresholds and coverage.

LAYER ORDER AND CHANNELS (the schema the material reads):
    weightmap A: R=snow  G=rock   B=scree      A=forest_floor
    weightmap B: R=wet_shore G=dirt_path B=gravel A=meadow

PRECEDENCE (first claim wins; later layers get the remainder):
    snow > rock > scree > forest_floor > wet_shore > dirt_path > gravel
    > meadow (remainder). Each weight is computed as its own 0..1 mask,
    then normalised by the running remainder, so the eight always sum
    to 1 -- the property the selftest asserts.

FORMULAS (sec 3.4-3.6, every number in the sidecar):
  snow          smoothstep over height above a PER-ASPECT snow line:
                line = base - 125*cos(aspect - north): north-facing holds
                snow 250 m lower than south-facing (alpine snow-line
                asymmetry, 200-300 m at mid-latitudes). x a slope term
                (full below 30 deg, gone by 40).
  rock          slope > 32 deg (smoothstep 29->35).
  scree         slope 20-32 deg AND within 60 m downhill of a >40 deg
                cell. "Downhill of" = a 60 m max-filter of the steep
                cells' heights; a cell qualifies when that local steep
                height EXCEEDS its own (the debris fell from above).
  forest_floor  canopy COVER fraction from the placed instances, each
                splatted as its crown disk and box-blurred by the crown
                radius; smoothstep 0.15->0.45 around the 0.3 threshold.
                NOTE ON UNITS (rule 9): the brief says "0.3 crowns/m^2";
                0.3 TREES per m^2 is denser than any forest (3.3 m^2 per
                tree), while 0.3 crown-AREA COVER is the standard canopy-
                cover figure -- read as COVER, recorded here.
  wet_shore     DECLARED ZERO: within-4-m-of-water needs Brief 4's water
                level, which does not exist yet. Zero with a reason, not
                silence.
  dirt_path     DECLARED ZERO: no path mask exists in this recipe -- the
                town's streets are ACTORS, not a landscape layer.
  gravel        the Gaea deposition export, gated below the treeline and
                off steep slopes, scaled to a 0..1 mask.
  meadow        the remainder.

Slope/aspect come from the SOURCE heightmap at full resolution -- the
same choice make_layer_weightmap made and for the same reason (the
rendered vertex normal changes with LOD; the heightmap does not).

  python scripts/derive_layer_weights.py [--out-prefix textures/alpine_8k_w8]
  python scripts/derive_layer_weights.py --selftest
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys

import numpy as np
from PIL import Image

Image.MAX_IMAGE_PIXELS = None
REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RECIPE = os.path.join(REPO, "recipes", "alpine_8k.json")

SNOW_BASE_M = 730.0        # DEFAULT ONLY -- main() reads the recipe's Snow
                           # band floor and asserts they agree (audit F2:
                           # a duplicated constant drifts silently)
SNOW_ASPECT_HALF_M = 125.0  # +-125 m -> 250 m N-S asymmetry (sec 3.5)
SNOW_FEATHER_M = 60.0
ROCK_DEG = (29.0, 35.0)     # smoothstep to full rock by 35, centred on 32
SCREE_DEG = (20.0, 32.0)
SCREE_SOURCE_DEG = 40.0
SCREE_RUNOUT_M = 60.0
CANOPY_COVER_BAND = (0.15, 0.45)
GRAVEL_MAX_SLOPE_DEG = 20.0


def smoothstep(lo, hi, x):
    t = np.clip((x - lo) / max(hi - lo, 1e-9), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def box_blur(a, r):
    """Separable box blur, radius r px, edge-padded (cumsum, no scipy).
    Cumsum in float64: a float32 running sum over 66M cells drifts."""
    if r < 1:
        return a
    k = 2 * r + 1
    c = np.cumsum(np.pad(a, ((r + 1, r), (0, 0)), mode="edge"), axis=0,
                  dtype=np.float64)
    a = (c[k:] - c[:-k]) / k
    c = np.cumsum(np.pad(a, ((0, 0), (r + 1, r)), mode="edge"), axis=1,
                  dtype=np.float64)
    return ((c[:, k:] - c[:, :-k]) / k).astype(np.float32)


def _shift_maxfill(a, s, axis):
    """a shifted by +s along axis, vacated cells filled with -inf (the
    identity for max: beyond the map there is no steep cell)."""
    out = np.full_like(a, -np.inf)
    src = [slice(None)] * a.ndim
    dst = [slice(None)] * a.ndim
    src[axis] = slice(s, None)
    dst[axis] = slice(None, a.shape[axis] - s)
    out[tuple(dst)] = a[tuple(src)]
    return out


def _one_sided_max(a, L, axis):
    """Windowed max over [x, x+L), EXACT, O(log L) full-array ops (the
    sparse-table two-block trick). The naive 121-shift stack was 32 GB
    at 8129 squared; this peaks at two extra arrays."""
    k = max(L.bit_length() - 1, 0)
    p = 1 << k
    f = a
    for i in range(k):
        f = np.maximum(f, _shift_maxfill(f, 1 << i, axis))
    if p == L:
        return f
    return np.maximum(f, _shift_maxfill(f, L - p, axis))


def max_filter(a, r):
    """Separable running-max over a (2r+1) square window, exact,
    memory-safe. Window [-r, +r] along an axis = max(forward window of
    length r+1, backward window of length r+1 on the reversed array)."""
    if r < 1:
        return a
    out = a.astype(np.float32)
    for axis in (0, 1):
        fwd = _one_sided_max(out, r + 1, axis)
        bwd = np.flip(_one_sided_max(np.flip(out, axis), r + 1, axis), axis)
        out = np.maximum(fwd, bwd)
    return out


def slope_aspect(h_m, spacing_m):
    gy, gx = np.gradient(h_m.astype(np.float32), spacing_m)
    slope = np.degrees(np.arctan(np.hypot(gx, gy)))
    # aspect: downhill direction, radians, 0 = +Y ("north" = map +Y).
    aspect = np.arctan2(-gx, -gy)
    return slope, aspect


def shaded_aspect_rad(sun_azimuth_deg):
    """The downhill direction of the SHADED aspect, in `aspect`'s frame.

    DERIVED, not a map axis (audit 2026-09-11 finding 1). The physical
    driver of snow-line asymmetry is which flank the sun misses, so the
    axis comes from `lighting.sun.azimuth_deg` -- which is the light
    actor's YAW, the direction light TRAVELS (ue-api-resolution's datum
    list: the sun sits at azimuth-180). A slope whose downhill points
    along the travel direction faces AWAY from the sun: that is the
    shaded aspect, and it holds snow lowest.

    `aspect` is atan2(dx, dy) -- angle from map +Y toward +X -- so the
    travel vector (cos az, sin az) maps to atan2(cos az, sin az).
    """
    az = math.radians(float(sun_azimuth_deg))
    return math.atan2(math.cos(az), math.sin(az))


def derive(h_m, spacing_m, flow01, depo01, cover01, snow_base_m=SNOW_BASE_M,
           shaded_rad=0.0):
    """The eight masks + precedence normalisation. Pure function of its
    inputs so the selftest runs it on synthetic terrain unchanged.
    REFUSES non-finite input: a NaN heightmap must not produce weights
    (direction 3 -- NaN propagates through every comparison as False and
    would yield a plausible all-meadow map)."""
    if not np.isfinite(h_m).all():
        raise ValueError("heightmap holds non-finite values -- refusing "
                         "to derive weights from it")
    slope, aspect = slope_aspect(h_m, spacing_m)

    # lowest snow line on the SHADED aspect (cos -> 1 there).
    line = snow_base_m - SNOW_ASPECT_HALF_M * np.cos(aspect - shaded_rad)
    snow = (smoothstep(-SNOW_FEATHER_M, SNOW_FEATHER_M, h_m - line)
            * (1.0 - smoothstep(30.0, 40.0, slope)))

    rock = smoothstep(ROCK_DEG[0], ROCK_DEG[1], slope)

    steep_h = np.where(slope > SCREE_SOURCE_DEG, h_m, -np.inf)
    r_px = max(1, int(round(SCREE_RUNOUT_M / spacing_m)))
    steep_near_h = max_filter(steep_h, r_px)
    scree_band = (smoothstep(SCREE_DEG[0] - 3, SCREE_DEG[0] + 3, slope)
                  * (1.0 - smoothstep(SCREE_DEG[1] - 3, SCREE_DEG[1] + 3,
                                      slope)))
    scree = np.where(steep_near_h > h_m + 1.0, scree_band, 0.0)

    forest = smoothstep(CANOPY_COVER_BAND[0], CANOPY_COVER_BAND[1], cover01)

    wet = np.zeros_like(h_m, dtype=np.float32)     # DECLARED ZERO (Brief 4)
    path = np.zeros_like(h_m, dtype=np.float32)    # DECLARED ZERO (no mask)

    gravel = (np.clip(depo01, 0.0, 1.0)
              * (1.0 - smoothstep(GRAVEL_MAX_SLOPE_DEG - 4,
                                  GRAVEL_MAX_SLOPE_DEG + 4, slope))
              * (1.0 - smoothstep(snow_base_m - 200, snow_base_m, h_m)))

    ordered = [("snow", snow), ("rock", rock), ("scree", scree),
               ("forest_floor", forest), ("wet_shore", wet),
               ("dirt_path", path), ("gravel", gravel)]
    remainder = np.ones_like(h_m, dtype=np.float32)
    weights = {}
    for name, m in ordered:
        w = np.clip(m, 0.0, 1.0).astype(np.float32) * remainder
        weights[name] = w
        remainder = remainder - w
    weights["meadow"] = np.clip(remainder, 0.0, 1.0)
    return weights, slope, aspect


def canopy_cover(shape, spacing_m, plans, origin_m, crown_r_m):
    """Canopy cover 0..1: each instance splats its crown DISK AREA into
    the cell grid (as area / cell area), then a crown-radius box blur
    spreads it; the result approximates local crown-area coverage."""
    cover = np.zeros(shape, dtype=np.float32)
    cell_area = spacing_m * spacing_m
    disk_area = math.pi * crown_r_m * crown_r_m
    n = 0
    for path in plans:
        doc = json.load(open(path, encoding="utf-8"))
        for inst in doc.get("instances", []):
            x_cm, y_cm = float(inst[0]), float(inst[1])
            px = int(round((x_cm / 100.0 - origin_m[0]) / spacing_m))
            py = int(round((y_cm / 100.0 - origin_m[1]) / spacing_m))
            if 0 <= py < shape[0] and 0 <= px < shape[1]:
                cover[py, px] += disk_area / cell_area
                n += 1
    r_px = max(1, int(round(crown_r_m / spacing_m)))
    cover = box_blur(cover, r_px)
    # blur conserves sum; convert to coverage by capping at full cover
    return np.clip(cover, 0.0, 1.0), n


def selftest():
    """Synthetic terrain, two decoupled specimens so no assertion leans
    on another layer's precedence:

    A. SNOW: a N/S ridge (crest at y=N/2, ~19 deg flanks), snow base
       chosen so the aspect-shifted lines straddle the flanks. Assert
       north >> south at the SAME height band.
    B. EVERYTHING ELSE: same ridge with snow pushed out of the world
       (base 5000 m), plus a 50 m cliff at x~180 (apron beyond it, lower)
       a dense stand, and a deposit fan. Scree is asserted GEOMETRICALLY
       (in the 60 m band beyond/below the cliff; absent far beyond and
       absent UPHILL of it) -- an independent statement of the rule, not
       a re-run of derive's own operator (the six-self-referential-
       properties lesson)."""
    N = 256
    sp = 1.0
    yy, xx = np.mgrid[0:N, 0:N].astype(np.float32)
    # plateau-topped ridge: FLAT crest strip (yy 98..158, slope 0) for
    # the gravel/meadow tests, 24.2 deg flanks (INSIDE the 20-32 scree
    # band) for the scree tests. 19 deg flanks failed the first run --
    # every scree mask was empty because the whole specimen sat below
    # the band, which the -1 sentinels made loud.
    ridge = 800.0 - np.maximum(np.abs(yy - N / 2) - 30.0, 0.0) * 0.45
    ok = True

    def check(name, cond):
        nonlocal ok
        print("  %-56s %s" % (name, "PASS" if cond else "FAIL"))
        ok = ok and bool(cond)

    zeros = np.zeros((N, N), dtype=np.float32)

    # --- A: snow asymmetry ------------------------------------------------
    # Sun due WEST in UE terms (yaw 270 = light travelling -Y), so the
    # SHADED flank is the one whose downhill points -Y: the y < N/2 side.
    # Asserted against an INDEPENDENT predicate (which side of the crest),
    # and the EXPECTED side is derived from the azimuth, so a sign flip
    # anywhere in gy/aspect/cos/shaded_rad fails this.
    shaded = shaded_aspect_rad(270.0)
    wA, slopeA, _ = derive(ridge, sp, zeros, zeros, zeros,
                           snow_base_m=780.0, shaded_rad=shaded)
    band = (ridge > 760) & (ridge < 780) & (slopeA > 5)
    minus_y = band & (yy < N / 2)   # downhill -Y == the shaded flank
    plus_y = band & (yy > N / 2)
    sn_sh = float(wA["snow"][minus_y].mean()) if minus_y.any() else 0
    sn_lit = float(wA["snow"][plus_y].mean()) if plus_y.any() else 0
    check("A: snow SHADED (%.2f) >> snow LIT (%.2f) at sun az 270"
          % (sn_sh, sn_lit), sn_sh > sn_lit + 0.5)
    # and the axis FOLLOWS the sun: flip the azimuth, flip the flanks.
    wA2, _, _ = derive(ridge, sp, zeros, zeros, zeros, snow_base_m=780.0,
                       shaded_rad=shaded_aspect_rad(90.0))
    sn_sh2 = float(wA2["snow"][plus_y].mean()) if plus_y.any() else 0
    check("A: flipping the sun flips the snowy flank (%.2f)" % sn_sh2,
          sn_sh2 > sn_sh - 0.05)
    totalA = sum(wA[k] for k in wA)
    check("A: weights sum to 1 (max err %.1e)"
          % float(np.abs(totalA - 1).max()),
          float(np.abs(totalA - 1).max()) < 1e-4)

    # --- B: rock / scree / forest / gravel / meadow -----------------------
    h = ridge - smoothstep(178.0, 186.0, xx) * 50.0   # cliff then lower apron
    cover = zeros.copy()
    cover[40:60, 40:60] = 1.0                          # dense stand (flank)
    depo = zeros.copy()
    depo[108:122, 210:240] = 0.8                       # fan on the FLAT crest
    wB, slopeB, _ = derive(h, sp, zeros, depo, cover, snow_base_m=5000.0)

    check("B: snow absent by construction (max %.2f)"
          % float(wB["snow"].max()), float(wB["snow"].max()) < 0.01)
    totalB = sum(wB[k] for k in wB)
    check("B: weights sum to 1 (max err %.1e)"
          % float(np.abs(totalB - 1).max()),
          float(np.abs(totalB - 1).max()) < 1e-4)

    cliff_px = slopeB > 40
    check("B: the cliff exists (%d px > 40 deg)" % int(cliff_px.sum()),
          int(cliff_px.sum()) > 200)
    check("B: rock claims the cliff (mean %.2f)"
          % float(wB["rock"][cliff_px].mean()),
          float(wB["rock"][cliff_px].mean()) > 0.8)

    # --- B2: scree on a clean single slope --------------------------------
    # A plane dipping +x at 24.2 deg (inside the scree band) with an
    # extra 50 m cliff drop at x 178-186. On THIS geometry "uphill of
    # the cliff" is unambiguous: every steep cell is lower than every
    # x<178 cell, so scree there must be zero. (The first ridge specimen
    # taught why: crest-adjacent cliff cells sit diagonally ABOVE flank
    # cells within the 60 m window, so the ridge has almost no true
    # uphill-of-cliff flank -- the code was right and the assertion's
    # geometry was wrong.)
    plane = 900.0 - xx * 0.45 - smoothstep(178.0, 186.0, xx) * 50.0
    wS, slopeS, _ = derive(plane, sp, zeros, zeros, zeros,
                           snow_base_m=5000.0)
    band = (slopeS > SCREE_DEG[0] + 1) & (slopeS < SCREE_DEG[1] - 1)
    apron = band & (xx > 190) & (xx < 240)
    far = band & (xx > 250)
    uphill = band & (xx > 60) & (xx < 170)
    s_ap = float(wS["scree"][apron].mean()) if apron.any() else -1
    s_far = float(wS["scree"][far].mean()) if far.any() else 1
    s_up = float(wS["scree"][uphill].mean()) if uphill.any() else 1
    check("B2: scree in the downhill apron (%.2f)" % s_ap, s_ap > 0.3)
    check("B2: scree absent beyond 60 m (%.2f)" % s_far, s_far < 0.05)
    check("B2: scree absent UPHILL of the cliff (%.2f)" % s_up,
          s_up < 0.05)

    inside = np.zeros((N, N), bool)
    inside[45:55, 45:55] = True
    open_ = np.zeros((N, N), bool)
    open_[105:125, 60:100] = True                      # flat crest, open
    ff_in = float(wB["forest_floor"][inside].mean())
    ff_out = float(wB["forest_floor"][open_].mean())
    check("B: forest_floor > 0.8 under the stand (%.2f)" % ff_in,
          ff_in > 0.8)
    check("B: forest_floor < 0.1 in the open (%.2f)" % ff_out,
          ff_out < 0.1)

    g = float(wB["gravel"][110:120, 215:235].mean())
    check("B: gravel follows the deposit fan (%.2f)" % g, g > 0.3)
    check("B: wet_shore and dirt_path declared zero",
          float(wB["wet_shore"].max()) == 0.0
          and float(wB["dirt_path"].max()) == 0.0)
    check("B: meadow takes the open remainder (%.2f)"
          % float(wB["meadow"][open_].mean()),
          float(wB["meadow"][open_].mean()) > 0.6)

    # direction 3: garbage in -> refuse, not crash-through
    try:
        derive(np.full((8, 8), np.nan, np.float32), sp,
               zeros[:8, :8], zeros[:8, :8], zeros[:8, :8])
        nan_ok = False
    except ValueError:
        nan_ok = True
    check("a NaN heightmap refuses", nan_ok)

    print("selftest:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


def collapse(prefix):
    """Fold the eight derived weights into the LIVE weightmap's channel
    contract (Brief 3 Task 2, v1 integration): the material and
    place_foliage index textures/alpine_8k_weights.png by LAYER POSITION
    (Snow, Rock, Grass), so

        R = snow
        G = rock + scree
        B = forest_floor + wet_shore + dirt_path + gravel + meadow
        A = forest_floor         (the v1.25 canopy tint driver)

    R+G+B sums to 1 by construction (the eight sum to 1 and every layer
    lands in exactly one bucket); asserted before writing. Per-layer
    SURFACES (scree vs rock, gravel vs meadow) arrive with Task 3's
    scans; this collapse is recorded in the sidecar as the v1 mapping."""
    wa = np.asarray(Image.open(os.path.join(REPO, prefix + "a.png"))
                    ).astype(np.float32) / 255.0
    wb = np.asarray(Image.open(os.path.join(REPO, prefix + "b.png"))
                    ).astype(np.float32) / 255.0
    snow, rock, scree, forest = [wa[..., i] for i in range(4)]
    wet, path, gravel, meadow = [wb[..., i] for i in range(4)]
    R = snow
    G = rock + scree
    B = forest + wet + path + gravel + meadow
    total = R + G + B
    err = float(np.abs(total - 1.0).max())
    if err > 0.02:  # 8-bit quantisation of 8 channels stacks to ~< 4/255
        raise ValueError("collapsed weights do not sum to 1 (max err "
                         "%.4f) -- refusing to write a weightmap that "
                         "would tint by the shortfall" % err)
    # renormalise the residual quantisation so the shader's mask sum is 1
    R, G, B = R / total, G / total, B / total
    img = np.stack([np.round(np.clip(c, 0, 1) * 255).astype(np.uint8)
                    for c in (R, G, B, forest)], axis=-1)
    out = os.path.join(REPO, "textures", "alpine_8k_weights.png")
    Image.fromarray(img, "RGBA").save(out)
    print("wrote textures/alpine_8k_weights.png (RGBA, collapsed; "
          "quantisation err %.4f renormalised)" % err)
    return 0


def expand(prefix):
    """Write the FIVE-LAYER live weightmap (Brief 3 Task 3, 2026-09-12).

    `collapse` was the v1 mapping, and its own docstring said per-layer
    surfaces "arrive with Task 3's scans". They have. This is what
    replaces it:

        R = snow            G = rock           B = scree
        A = forest_floor    meadow = 1-(R+G+B+A), DERIVED IN THE SHADER

    ⛔ THE CHANNELS ARE ALREADY THIS. `w8a` was written with exactly this
    contract on 2026-09-11, so expanding is a COPY plus two assertions,
    not a recomputation -- there is no second derivation to disagree with
    the first.

    THE REMAINDER IS NOT STORED. A fifth channel would be a fifth number
    obliged to agree with four others, and 8-bit quantisation guarantees
    it sometimes would not (NN24). Deriving it in the shader makes the
    masks sum to 1 by construction.

    WHAT IS ASSERTED, and why each one can fail:
      1. R+G+B+A <= 1 within quantisation -- if it exceeds 1 the shader's
         remainder goes negative and a layer renders as a black bruise.
      2. the remainder EQUALS gravel+meadow from w8b -- this is the claim
         that folding gravel into meadow is what actually happens, and it
         is checked against the OTHER file rather than asserted in prose.
      3. wet_shore and dirt_path are still identically ZERO -- the reason
         they are not layers. If either ever becomes non-zero this
         refuses, because the justification has expired.
    """
    wa = np.asarray(Image.open(os.path.join(REPO, prefix + "a.png"))
                    ).astype(np.float32) / 255.0
    wb = np.asarray(Image.open(os.path.join(REPO, prefix + "b.png"))
                    ).astype(np.float32) / 255.0
    snow, rock, scree, forest = [wa[..., i] for i in range(4)]
    wet, path, gravel, meadow = [wb[..., i] for i in range(4)]

    total = snow + rock + scree + forest
    over = float((total - 1.0).max())
    if over > 0.02:
        raise ValueError("the four stored channels exceed 1 by %.4f -- the "
                         "shader remainder would go NEGATIVE and that layer "
                         "renders as a black bruise" % over)

    remainder = 1.0 - total
    expect = gravel + meadow
    gap = float(np.abs(remainder - expect).max())
    if gap > 0.02:
        raise ValueError("the derived remainder disagrees with gravel+meadow "
                         "by %.4f -- 'gravel folds into meadow' is then a "
                         "claim the data does not support" % gap)

    for nm, ch in (("wet_shore", wet), ("dirt_path", path)):
        mx = float(ch.max())
        if mx > 0.004:   # 1/255
            raise ValueError(
                "%s is no longer identically zero (max %.4f). It was left "
                "out of the layer set BECAUSE it was zero; that reason has "
                "expired and the omission must be re-decided, not carried."
                % (nm, mx))

    out = os.path.join(REPO, "textures", "alpine_8k_weights.png")
    img = np.round(np.clip(wa, 0.0, 1.0) * 255).astype(np.uint8)
    Image.fromarray(img, "RGBA").save(out)
    cov = {"snow": float(snow.mean()), "rock": float(rock.mean()),
           "scree": float(scree.mean()), "forest_floor": float(forest.mean()),
           "meadow_remainder": float(remainder.mean())}
    print("wrote textures/alpine_8k_weights.png (RGBA, FIVE-LAYER contract)")
    print("  sum(stored) max over 1: %.5f   remainder vs gravel+meadow: "
          "%.5f" % (over, gap))
    for k, v in cov.items():
        print("  %-18s %6.2f%%" % (k, 100.0 * v))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--collapse", action="store_true",
                    help="v1 THREE-layer mapping: G=rock+scree, "
                         "B=everything else. SUPERSEDED by --expand")
    ap.add_argument("--expand", action="store_true",
                    help="the FIVE-layer contract: R=snow G=rock B=scree "
                         "A=forest_floor, meadow as the shader remainder")
    ap.add_argument("--out-prefix", default="textures/alpine_8k_w8")
    a = ap.parse_args(argv)
    if a.selftest:
        return selftest()
    if a.collapse and a.expand:
        print("REFUSE: --collapse and --expand write the SAME file with "
              "DIFFERENT channel contracts; pick one")
        return 2
    if a.collapse:
        return collapse(a.out_prefix)
    if a.expand:
        return expand(a.out_prefix)

    rec = json.load(open(RECIPE, encoding="utf-8"))
    ls = rec["landscape"]
    spacing_m = float(ls["scale_xy_cm"]) / 100.0
    origin_m = (float(ls["location_cm"][0]) / 100.0,
                float(ls["location_cm"][1]) / 100.0)
    z_span_m = float(ls["z_scale_cm"]) / 100.0
    z_base_m = (float(ls["location_cm"][2]) - float(ls["z_scale_cm"]) / 2.0) / 100.0

    hpath = os.path.join(REPO, rec["heightmap"]["source"])
    h16 = np.asarray(Image.open(hpath)).astype(np.float32)
    if h16.ndim != 2:
        print("REFUSE: heightmap is not single-channel")
        return 3
    h_m = h16 / 65535.0 * z_span_m + z_base_m
    if not np.isfinite(h_m).all():
        print("REFUSE: heightmap holds non-finite values")
        return 3
    shape = h_m.shape
    print("heightmap %s  spacing %.1f m  z %.1f..%.1f m"
          % (shape, spacing_m, float(h_m.min()), float(h_m.max())))

    def load01(rel):
        p = os.path.join(REPO, rel)
        a16 = np.asarray(Image.open(p).convert("I")).astype(np.float32)
        if a16.shape != shape:
            im = Image.fromarray(a16)
            a16 = np.asarray(im.resize((shape[1], shape[0]),
                                       Image.BILINEAR)).astype(np.float32)
        return a16 / max(float(a16.max()), 1e-6)

    # flow is RESERVED (audit F3): the brief gates wet_shore on Brief 4's
    # water level and gravel on deposition; nothing reads flow yet, so it
    # is neither loaded nor claimed as an input.
    depo = load01("terrain/alpine_8k_deposition.png")
    flow = np.zeros_like(depo)

    # The snow floor comes from the RECIPE's Snow band, not a local copy.
    snow_layer = [l for l in rec["material"]["layers"]
                  if l["name"] == "Snow"]
    if not snow_layer:
        print("REFUSE: the recipe declares no Snow layer to take the "
              "snow-line floor from")
        return 2
    snow_base = float(snow_layer[0]["height_m"][0])
    sun_az = float(rec["lighting"]["sun"]["azimuth_deg"])
    shaded = shaded_aspect_rad(sun_az)
    print("snow floor %.0f m (from the recipe's Snow band); sun azimuth "
          "%.1f deg -> shaded aspect %.1f deg from +Y"
          % (snow_base, sun_az, math.degrees(shaded)))

    crown_r = float(rec["placement_priors"]["canopy"]["radius_m"]) \
        if rec.get("placement_priors", {}).get("canopy") else 3.068
    plans = [os.path.join(REPO, "foliage", "alpine_8k_%s.json" % s)
             for s in ("Conifer", "ConiferPine", "SpruceSub",
                       "SpruceSapling")]
    plans = [p for p in plans if os.path.isfile(p)]
    cover, n_inst = canopy_cover(shape, spacing_m, plans, origin_m, crown_r)
    print("canopy: %d instances splatted, crown %.2f m, cover p99 %.2f"
          % (n_inst, crown_r, float(np.percentile(cover, 99))))

    weights, slope, aspect = derive(h_m, spacing_m, flow, depo, cover,
                                    snow_base_m=snow_base,
                                    shaded_rad=shaded)

    A = ["snow", "rock", "scree", "forest_floor"]
    B = ["wet_shore", "dirt_path", "gravel", "meadow"]
    outs = {}
    for suffix, names in (("a", A), ("b", B)):
        img = np.stack([np.round(weights[n] * 255).astype(np.uint8)
                        for n in names], axis=-1)
        rel = a.out_prefix + suffix + ".png"
        Image.fromarray(img, "RGBA").save(os.path.join(REPO, rel))
        outs[suffix] = rel
        print("wrote %s" % rel)

    side = {
        "_what": ("Eight DERIVED layer weights (Brief 3 Task 2, sec "
                  "3.4-3.6). Weights sum to 1; precedence and formulas "
                  "in derive_layer_weights docstring; nothing painted."),
        "inputs": {"heightmap": rec["heightmap"]["source"],
                   "flow": "RESERVED, not read (Brief 4 supplies the "
                           "water level wet_shore needs)",
                   "deposition": "terrain/alpine_8k_deposition.png",
                   "foliage_plans": [os.path.relpath(p, REPO) for p in plans],
                   "crown_radius_m": crown_r,
                   "instances": n_inst},
        "channels": {"a": A, "b": B, "files": outs},
        "constants": {"snow_base_m": snow_base,
                      "_snow_base_m": "read from the recipe's Snow band "
                                      "floor, not a local constant",
                      "sun_azimuth_deg": sun_az,
                      "shaded_aspect_deg_from_plus_y":
                          round(math.degrees(shaded), 2),
                      "_shaded_aspect": "DERIVED from the sun azimuth "
                                        "(the light's travel yaw; the "
                                        "shaded flank faces along it), "
                                        "never a map axis",
                      "snow_aspect_half_m": SNOW_ASPECT_HALF_M,
                      "rock_deg": ROCK_DEG, "scree_deg": SCREE_DEG,
                      "scree_source_deg": SCREE_SOURCE_DEG,
                      "scree_runout_m": SCREE_RUNOUT_M,
                      "canopy_cover_band": CANOPY_COVER_BAND,
                      "gravel_max_slope_deg": GRAVEL_MAX_SLOPE_DEG},
        "declared_zero": {
            "wet_shore": "needs Brief 4's water level; zero with a "
                         "reason, not silence",
            "dirt_path": "no path mask exists; the town's streets are "
                         "ACTORS, not a landscape layer"},
        "units_note": ("the brief's forest-floor threshold '0.3 "
                       "crowns/m2' is read as 0.3 crown-area COVER (a "
                       "canopy-cover figure); 0.3 trees/m2 is denser "
                       "than any forest"),
        "coverage_fraction": {k: round(float(v.mean()), 4)
                              for k, v in weights.items()},
    }
    sp_path = os.path.join(REPO, a.out_prefix + "_sidecar.json")
    with open(sp_path, "w", encoding="utf-8") as fh:
        json.dump(side, fh, indent=1)
    print("wrote %s" % os.path.relpath(sp_path, REPO))
    for k, v in side["coverage_fraction"].items():
        print("  %-14s %6.2f%%" % (k, v * 100))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
