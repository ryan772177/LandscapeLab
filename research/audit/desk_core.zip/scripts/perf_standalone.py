"""perf_standalone.py — E3: frame cost in a STANDALONE `-game` process.

WHY THIS EXISTS RATHER THAN perf_flythrough.py
----------------------------------------------
Both existing perf tools drive the EDITOR viewport, and the editor is the
suspect. `check_perf.py` has been RED on plaza at Game 14.00 ms against a
12.00 budget, and REGISTER records the reason to doubt it: "game thread
pinned at 13.9-14.15 ms on all four zones regardless of content". A number
that does not move when the content moves is measuring the instrument.

So this measures the same four ratified stations with the editor gone.

**IT DOES NOT RE-RATIFY ANYTHING.** The budgets in `recipes/perf_budgets.json`
are law and are untouched. This writes a second, independent measurement
beside them and says how the two differ. Whether the budgets should move is an
operator decision, not this script's.

HOW A STANDALONE RUN IS DRIVEN, AND WHAT THAT COSTS
---------------------------------------------------
`-game` has no Python and no remote channel, so `-ExecCmds` -- which fires
ONCE at startup -- is the only lever. Two consequences, both handled here
rather than hidden:

  * THE CAMERA IS MOVED WITH `BugItGo`, not `ViewActor`. BugItGo takes the
    ratified coordinates straight from perf_budgets.json and needs no camera
    actor to exist under a name this script cannot verify offline. The move is
    then proven by `getall PlayerController Location`, whose value is LOGGED
    and compared against the requested station. Searching the log for the
    string "BugItGo" proves nothing -- the log echoes the command line
    verbatim, so that check passes even when the command never ran.

  * THE WINDOW IS THE TAIL OF THE CAPTURE. Warmup cannot be timed, and the
    first attempt -- drop WARMUP_S from the front -- left nothing at all: the
    whole capture was 755 frames of startup, because at the resolution the
    run actually got, the engine outran the requested frame count before the
    world was up. Taking the LAST MIN_WINDOW_S needs no assumption about when
    loading finished. A capture too short to contain a full window is
    reported short, not averaged over whatever arrived.

  * RESOLUTION IS FORCED WITH `r.setRes` AND READ BACK FROM ENGINE METADATA.
    `-ResX/-ResY` LOSES to config: the first run logged
    `Set CVar [[r.setres:1280x720]]` and measured 720p while reporting 4K,
    because the read-back regex matched the command line the log echoes.
    The honest source is the CsvProfiler's `systemresolution.resx/resy`.

Reuses `measure_frame_cost._reduce` and `._newest_csv`: non-negotiable 4a.
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re
import shutil
import subprocess
import sys
import time

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(REPO_ROOT, "scripts"))

import bootstrap                                    # noqa: E402
import measure_frame_cost as mfc                    # noqa: E402

UE_EXE = r"C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe"
UPROJECT = os.path.join(bootstrap.UE_PROJECT_ROOT, "LandscapeLab.uproject")
LOG_DIR = os.path.join(bootstrap.UE_PROJECT_ROOT, "Saved", "Logs")

RES_X, RES_Y = 3840, 2160
MIN_WINDOW_S = 25.0
SETTLE_S = 60.0        # world load + streaming + shader warmup, discarded
MARGIN_S = 20.0        # slack so the tail is comfortably inside steady state
FRAMES = 60000         # effectively unbounded: the DWELL bounds the capture,
                       # not the frame count. A frame budget that expires
                       # mid-run ends the capture wherever it happens to be.
EYE_CM = 175.0
COLUMNS = ("GPUTime", "GameThreadTime", "RenderThreadTime", "FrameTime")


def heightmap_z(x_cm, y_cm, recipe):
    """Ground Z from the heightmap. A PLACEMENT AID, not a trace.

    perf_budgets.json is explicit that ground is traced in-editor, and that
    this project once shipped a render/collide divergence of p90 30.98 m. The
    measured gap at near_ground is 2.3 cm, so for standing a camera at eye
    height the heightmap is adequate -- and the standalone pawn collides
    anyway. Recorded as `z_source` so nobody reads it as a trace.
    """
    import numpy as np
    from PIL import Image
    ls = recipe["landscape"]
    hm = os.path.join(REPO_ROOT, recipe["heightmap"]["source"])
    a = np.asarray(Image.open(hm)).astype(float)
    n = a.shape[0]
    scale = float(ls["scale_xy_cm"])
    loc = ls["location_cm"]
    z_scale = float(ls["z_scale_cm"])
    col = int(round((x_cm - loc[0]) / scale))
    row = int(round((y_cm - loc[1]) / scale))
    col = max(0, min(n - 1, col))
    row = max(0, min(n - 1, row))
    frac = a[row, col] / 65535.0
    return loc[2] + (frac - 0.5) * z_scale


def newest_log():
    logs = glob.glob(os.path.join(LOG_DIR, "*.log"))
    return max(logs, key=os.path.getmtime) if logs else None


def run_station(zone, x, y, z, pitch, yaw, outdir, dry=False,
                settle_s=SETTLE_S):
    before = set(glob.glob(os.path.join(mfc.CSV_DIR, "*.csv")))
    os.makedirs(mfc.CSV_DIR, exist_ok=True)
    log_name = "perf_standalone_%s.log" % zone
    # ORDER MATTERS AND EVERY ITEM EARNS ITS PLACE.
    #   r.setRes  -- `-ResX/-ResY` on the command line LOSES to config. The
    #               first run logged `LogConfig: Set CVar [[r.setres:1280x720]]`
    #               and the engine's own metadata recorded
    #               systemresolution.resx=1280: a 720p measurement wearing a
    #               4K label. ExecCmds runs after config, so it wins.
    #   BugItGo   -- moves the camera to the ratified station.
    #   NO getall -- `getall PlayerController Location` printed NOTHING:
    #               `Location` is not a UPROPERTY on the controller. So camera
    #               placement is UNVERIFIED IN-PROCESS and is declared as such
    #               rather than asserted. Cross-station differentiation is the
    #               only check available and is applied after the run: if the
    #               four stations come back near-identical, BugItGo did not
    #               move anything and the run must be discarded.
    #   CsvProfile-- last, so the capture starts after the move.
    exec_cmds = ",".join([
        "r.setRes %dx%dw" % (RES_X, RES_Y),
        "BugItGo %.1f %.1f %.1f %.1f %.1f 0" % (x, y, z, pitch, yaw),
        "CsvProfile frames=%d" % FRAMES,
    ])
    cmd = [UE_EXE, UPROJECT, "/Game/Alpine8K",
           "-game", "-windowed",
           "-ResX=%d" % RES_X, "-ResY=%d" % RES_Y,
           "-ExecCmds=%s" % exec_cmds,
           "-nosplash", "-NoLoadingScreen",
           "-AbsLog=%s" % os.path.join(LOG_DIR, log_name)]
    rec = {"zone": zone, "cmd": cmd, "exec_cmds": exec_cmds,
           "camera": {"x_cm": x, "y_cm": y, "z_cm": z,
                      "pitch_deg": pitch, "yaw_deg": yaw},
           "requested_res": [RES_X, RES_Y]}
    if dry:
        rec["dry_run"] = True
        return rec

    t0 = time.time()
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)
    # DWELL FOR A FIXED WALL TIME. DO NOT RACE THE FILE.
    #
    # The previous version polled for the CSV to exist with size > 0 and then
    # terminated. The profiler writes INCREMENTALLY, so that caught a
    # PARTIAL file about 8 s in and the kill truncated the capture -- and
    # those 8 s were the level load, carrying a 4,626 ms GameThread hitch. It
    # looked like a completed measurement.
    #
    # Dwelling a fixed time needs no assumption about the profiler's flush
    # behaviour: let the world load and settle, keep running well past that,
    # then stop and take the TAIL.
    deadline = t0 + settle_s + MIN_WINDOW_S + MARGIN_S
    while time.time() < deadline:
        time.sleep(5.0)
        if proc.poll() is not None:
            break
    rec["dwell_s"] = round(time.time() - t0, 1)
    csv_path = mfc._newest_csv(before)
    try:
        proc.terminate()
        proc.wait(timeout=60)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass

    # ---- read the LOG back: did the console accept BugItGo, and at what res?
    lp = os.path.join(LOG_DIR, log_name)
    if not os.path.exists(lp):
        lp = newest_log()
    rec["log"] = os.path.relpath(lp, REPO_ROOT) if lp else None
    if lp and os.path.exists(lp):
        txt = open(lp, "r", encoding="utf-8", errors="replace").read()
        # ---- RESOLUTION, from the ENGINE, not from my own command line ----
        # The CsvProfiler writes `systemresolution.resx/resy` as metadata. The
        # first version regexed `ResX=(\d+)` and matched the COMMAND LINE the
        # log echoes verbatim, reporting [3840, 2160] over a 1280x720 run.
        # That is reading back my own input -- the same class of error as
        # trusting a MaterialInstanceDynamic's parameter getter.
        mres = re.findall(
            r'systemresolution\.resx="(\d+)".*?systemresolution\.resy="(\d+)"',
            txt, re.S)
        rec["viewport_res_readback"] = ([int(mres[-1][0]), int(mres[-1][1])]
                                        if mres else None)
        rec["res_matches_request"] = (
            rec["viewport_res_readback"] == [RES_X, RES_Y])
        setres = re.findall(r"Set CVar \[\[r\.setres:(\d+)x(\d+)", txt)
        rec["config_setres_seen"] = ([int(setres[-1][0]), int(setres[-1][1])]
                                     if setres else None)

        # ---- DID THE CAMERA ACTUALLY MOVE? --------------------------------
        # `getall PlayerController Location` prints the value. Searching for
        # the string "BugItGo" only proves the log echoed the command line.
        locs = re.findall(r"Location = \(?X=(-?[\d.]+),?\s*Y=(-?[\d.]+),?"
                          r"\s*Z=(-?[\d.]+)", txt)
        rec["pc_location_logged"] = ([float(v) for v in locs[-1]]
                                     if locs else None)
        if rec["pc_location_logged"]:
            dx = rec["pc_location_logged"][0] - x
            dy = rec["pc_location_logged"][1] - y
            rec["camera_move_error_cm"] = round((dx * dx + dy * dy) ** 0.5, 1)
            rec["camera_moved"] = rec["camera_move_error_cm"] < 500.0
        else:
            rec["camera_moved"] = None
        rec["command_not_recognized"] = bool(
            re.search(r"[Cc]ommand not recognized", txt))

    if not csv_path:
        rec["error"] = "no CSV appeared within the window"
        return rec

    dst = os.path.join(outdir, "%s.csv" % zone)
    shutil.copy2(csv_path, dst)
    rec["csv"] = os.path.relpath(dst, REPO_ROOT)

    # ---- frame timeline, to convert the warmup into a row count -----------
    full = mfc._reduce(dst)
    ft = full.get("FrameTime")
    if not ft:
        rec["error"] = "CSV carries no FrameTime column"
        return rec
    # TAKE THE TAIL, NOT A FIXED WARMUP SKIP.
    #
    # The first attempt dropped `WARMUP_S` worth of frames from the front and
    # left NOTHING: the whole capture was 755 frames of startup, because at
    # 720p during load the engine outran the requested frame count before the
    # world was up. Selecting the LAST MIN_WINDOW_S of the capture needs no
    # assumption about when loading finished -- the tail is steady state by
    # construction, and if the capture is too short to contain a full window
    # that is reported rather than averaged over whatever arrived.
    mean_ms = ft["mean"]
    rec["frames_total"] = ft["n"]
    want = int(MIN_WINDOW_S * 1000.0 / mean_ms) if mean_ms > 0 else ft["n"]
    skip = max(0, ft["n"] - want)
    rec["frames_dropped_from_front"] = skip
    remaining = ft["n"] - skip
    rec["window_s_measured"] = round(remaining * mean_ms / 1000.0, 1)
    rec["window_ok"] = rec["window_s_measured"] >= MIN_WINDOW_S * 0.95
    rec["capture_s_total"] = round(ft["n"] * mean_ms / 1000.0, 1)
    stats = mfc._reduce(dst, skip_frames=skip)
    rec["stats_ms"] = {k: {kk: round(vv, 3) for kk, vv in v.items()}
                       for k, v in stats.items() if k in COLUMNS}
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default=os.path.join("_verify", "perf"))
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--only", default="", help="one zone name")
    ap.add_argument("--settle", type=float, default=SETTLE_S,
                    help="seconds to let the world load and settle BEFORE the "
                         "measured window. The default assumes a WARM DDC. On "
                         "a cold cache the first station spends its whole "
                         "dwell compiling shaders -- measured 2026-09-08: "
                         "8,263 jobs still dispatching at expiry and no CSV "
                         "was ever written.")
    a = ap.parse_args()

    budgets = json.load(open(os.path.join(REPO_ROOT, "recipes",
                                          "perf_budgets.json"),
                             encoding="utf-8-sig"))
    recipe = json.load(open(os.path.join(REPO_ROOT, "recipes",
                                         "alpine_8k.json"),
                            encoding="utf-8-sig"))
    spline = budgets["spline"]
    eye = float(spline.get("eye_height_cm", EYE_CM))

    # The subdir used to be the HARDCODED literal "standalone_2026-09-07"
    # -- a date baked into the tool, so every later run masqueraded as
    # the 09-07 one (caught 2026-09-10 when the range sweeps landed in
    # oddly-named nests). The artefact's identity now comes from the run.
    import datetime as _dt
    outdir = os.path.join(REPO_ROOT, a.outdir,
                          "standalone_" + _dt.date.today().isoformat())
    os.makedirs(outdir, exist_ok=True)

    out = {
        "_what": "E3: frame cost measured in a STANDALONE -game process, at "
                 "the four ratified perf stations.",
        "_not_a_ratification": "recipes/perf_budgets.json is LAW and is "
                               "untouched. This is a second instrument "
                               "reported beside it. Whether any budget should "
                               "move is an operator decision.",
        "engine": UE_EXE, "project": UPROJECT, "level": "/Game/Alpine8K",
        "requested_res": [RES_X, RES_Y], "fov_h_deg": spline.get(
            "fov_horizontal_deg"), "eye_height_cm": eye,
        "settle_s": a.settle, "margin_s": MARGIN_S,
        "min_window_s": MIN_WINDOW_S,
        "frames_requested": FRAMES,
        "z_source": "heightmap-derived + eye height; a PLACEMENT AID, not a "
                    "trace. perf_budgets.json requires an in-editor trace; "
                    "the measured gap at near_ground is 2.3 cm and the "
                    "standalone pawn collides.",
        "camera_command": "BugItGo (not ViewActor): it takes the ratified "
                          "coordinates directly and needs no named camera "
                          "actor. The log is checked for the echo AND for "
                          "'not recognized'.",
        "zones": {},
    }

    for st in spline["stations"]:
        zone = st["zone"]
        if a.only and zone != a.only:
            continue
        x, y = st["xy_cm"]
        z = heightmap_z(x, y, recipe) + eye
        rec = run_station(zone, x, y, z, st["pitch_deg"], st["yaw_deg"],
                          outdir, dry=a.dry_run, settle_s=a.settle)
        out["zones"][zone] = rec
        print("  %-12s %s" % (zone, "DRY" if a.dry_run else
                              ("ok  window %.1f s  GPU p90 %s  Game p90 %s"
                               % (rec.get("window_s_measured", 0),
                                  (rec.get("stats_ms", {}).get("GPUTime") or
                                   {}).get("p90"),
                                  (rec.get("stats_ms", {}).get(
                                      "GameThreadTime") or {}).get("p90"))
                               if "stats_ms" in rec else rec.get("error"))))

    # A RUN THAT MEASURED NOTHING MUST NOT OVERWRITE A RUN THAT DID.
    #
    # Measured 2026-09-08, twice in ten minutes. First: every station returned
    # "no CSV appeared" on a cold DDC -- I had emptied it hours earlier to free
    # 92 GB -- and the sidecar was rewritten with four empty records, wiping a
    # complete result. Second: a `--dry-run --only plaza` wrote a single
    # dry_run record over the restored file. Git had it both times, and rule 3
    # earned its keep, but a tool should not need rescuing from itself.
    #
    # A dry run writes NOTHING: it exists to show what would be launched.
    dest = os.path.join(outdir, "perf_standalone.json")
    if a.dry_run:
        print("dry run: no sidecar written")
        return 0
    measured = [z for z in out["zones"].values() if z.get("stats_ms")]
    if not measured and os.path.exists(dest):
        print("REFUSING to write %s: no station produced data and a result "
              "already exists there. Nothing measured, nothing overwritten."
              % os.path.relpath(dest, REPO_ROOT))
        for k, v in out["zones"].items():
            print("    %-12s %s" % (k, v.get("error") or "no stats"))
        return 1
    with open(dest, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=2)
    print("wrote %s" % os.path.relpath(dest, REPO_ROOT))
    return 0


if __name__ == "__main__":
    sys.exit(main())
