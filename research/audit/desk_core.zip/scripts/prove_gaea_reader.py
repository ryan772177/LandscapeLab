"""Positive control for read_gaea_graph's gates. Scratch copies only —
the real .terrain is never touched."""
import json, os, shutil, subprocess, sys, tempfile

REPO = r"C:\Users\Admin\UE5LandscapePipeline"
SRC = r"C:\Dev\LandscapeLab\TerrainData\AlpineLab_v1\AlpineLabe_v1.terrain"
TOOL = os.path.join(REPO, "scripts", "read_gaea_graph.py")
tmp = tempfile.mkdtemp(prefix="gaea_probe_")

def run(path, *extra):
    r = subprocess.run([sys.executable, TOOL, "--project", path] + list(extra),
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace", cwd=REPO)
    return r.returncode

def mutate(fn):
    d = json.load(open(SRC, encoding="utf-8"))
    fn(d)
    p = os.path.join(tmp, "m.terrain")
    json.dump(d, open(p, "w", encoding="utf-8"))
    return p

fails = []

def expect(label, path, args, want_refuse):
    rc = run(path, *args)
    refused = rc != 0
    ok = refused == want_refuse
    print("  %-9s %-52s rc=%d" % ("refused" if refused else "accepted",
                                  label, rc))
    if not ok:
        fails.append(label)

print("POSITIVE CONTROLS — the shipped graph must be ACCEPTED")
expect("shipped graph, all gates", SRC,
       ["--check-refs", "--check-spec",
        "--against-build",
        r"C:\Dev\LandscapeLab\TerrainData\AlpineLab_v1\006"], False)

print()
print("NEGATIVE CONTROLS — each must be REFUSED")

# 1. A save node disabled in the GUI. The build silently omits three maps.
def disable_erosion(d):
    t = d["Assets"]["$values"][0]["Terrain"]
    t["Nodes"]["654"]["SaveDefinition"]["IsEnabled"] = False
expect("a save node DISABLED (build would omit 3 maps)",
       mutate(disable_erosion), ["--check-spec"], True)

# 2. A save node removed entirely.
def drop_snowmask(d):
    t = d["Assets"]["$values"][0]["Terrain"]
    del t["Nodes"]["849"]["SaveDefinition"]
expect("a save definition REMOVED", mutate(drop_snowmask),
       ["--check-spec"], True)

# 3. An output port stops exporting -> one file vanishes.
def unexport_flow(d):
    t = d["Assets"]["$values"][0]["Terrain"]
    for p in t["Nodes"]["654"]["Ports"]["$values"]:
        if p.get("Name") == "Flow":
            p["IsExporting"] = None
expect("an output port stops EXPORTING", mutate(unexport_flow),
       ["--check-spec"], True)

# 4. A dangling $ref — what a careless structural edit produces.
def break_ref(d):
    t = d["Assets"]["$values"][0]["Terrain"]
    t["Nodes"]["654"]["Ports"]["$values"][0]["Parent"]["$ref"] = "99999"
expect("a DANGLING $ref (careless structural edit)", mutate(break_ref),
       ["--check-refs"], True)

# 5. The prediction rule vs a build directory that does not match.
expect("prediction vs a build MISSING files", SRC,
       ["--against-build", tmp], True)

shutil.rmtree(tmp, ignore_errors=True)
print()
print("FAILURES:", fails if fails else "none")
sys.exit(1 if fails else 0)
