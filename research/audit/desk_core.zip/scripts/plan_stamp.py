"""The single declaration of what a PLAN's inputs are, and their hashes.

Imported by `plan_city.py`, `plan_encounters.py` (which WRITE the stamp) and
`check_plan_freshness.py` (which READS it). One declaration, three consumers.

WHY IT IS A MODULE AND NOT THREE COPIES
---------------------------------------
`INPUT_KEYS` is a requirement checked in more than one place: a producer stamps
them, a checker verifies them. Non-negotiable 24 -- two lists that must agree
are one list, badly stored, and the test is whether adding an input key can be
done in one place and forgotten in another. Written three times it can; written
once it cannot.

WHY A STAMP AT ALL
------------------
Non-negotiable 20: an adopted artefact is hash-proven against its source AT
ADOPTION TIME. Before this, plans carried their inputs' PATHS and not their
HASHES, which is the live-pointer problem -- "is this plan current" was
answerable only by re-running the producer, whose own inputs may have moved
since. A stamp makes staleness a FACT ON DISK.

    `encounters/alpine_8k_all.json` sat in the repo carrying five encounters
    that its producer had stopped generating, and nothing could tell.

WHAT THE STAMP DOES NOT DO
--------------------------
It proves the INPUTS are unchanged. It does not prove the OUTPUT is what those
inputs would produce today -- a non-deterministic producer, or one whose
behaviour depends on something it does not declare, can still drift. Only
re-derivation settles that, which is why `check_plan_freshness.py --reproduce`
exists and why the stamp is the CHEAP instrument, not the authority.
"""
import hashlib
import io
import os

# Keys whose value is a repo-relative path to an INPUT of the plan.
# `_produced_by` is an input too: a planner change can move its output.
INPUT_KEYS = ("_produced_by", "_recipe", "_world", "_biome",
              "_terrain_source", "_character", "_reachable_sidecar",
              # Added 2026-09-12b with the foliage settlement exclusion.
              # The committed town plan is a REAL input to any plan that
              # excludes the town from itself: move a building and the
              # foliage plan is stale, with nothing else on disk saying so.
              # Absent keys are skipped above, so plans that avoid no town
              # are unaffected.
              "_city_plan")

STAMP_KEY = "_input_sha256"


def sha256_file(path):
    return hashlib.sha256(io.open(path, "rb").read()).hexdigest()


def declared_inputs(doc, repo_root):
    """-> (found, missing), each a list of (key, repo-relative path).

    A declared path that does NOT exist is returned separately rather than
    dropped. A plan naming a deleted recipe would otherwise read as a plan with
    no inputs, and therefore as merely unstamped instead of broken.
    """
    found, missing = [], []
    for k in INPUT_KEYS:
        v = doc.get(k)
        if not isinstance(v, str) or "/" not in v:
            continue
        if os.path.exists(os.path.join(repo_root, v)):
            found.append((k, v))
        else:
            missing.append((k, v))
    return found, missing


def stamp(doc, repo_root):
    """The {path: sha256} map for everything `doc` declares as an input.

    REFUSES on a declared-but-absent input rather than stamping around it: a
    stamp that silently omits an input it could not read is a stamp that will
    later verify clean against a plan built from something else.
    """
    found, missing = declared_inputs(doc, repo_root)
    if missing:
        raise RuntimeError(
            "cannot stamp: %d declared input(s) do not exist -- %s"
            % (len(missing), ", ".join("%s=%s" % kv for kv in missing)))
    if not found:
        raise RuntimeError(
            "cannot stamp: the document declares no input paths. Add at least "
            "_produced_by and _recipe before writing it, or a reader has no "
            "way to tell this plan from a stale one.")
    return {v: sha256_file(os.path.join(repo_root, v)) for _, v in found}


def verify(doc, repo_root):
    """-> (verdict, rows). Verdict is one of:

        MATCHES      every stamped input hashes to its recorded value
        DIFFERS      at least one input has changed since the plan was written
        UNSTAMPED    no stamp -- CANNOT CHECK, which is not the same as fresh
        UNREADABLE   a stamped input is gone or cannot be read

    rows is [(path, recorded, actual_or_None)] for anything that did not match,
    so a caller can name WHICH input moved rather than only that one did.
    """
    rec = doc.get(STAMP_KEY)
    if not isinstance(rec, dict) or not rec:
        return "UNSTAMPED", []
    bad = []
    unreadable = False
    for path, recorded in sorted(rec.items()):
        ap = os.path.join(repo_root, path)
        if not os.path.exists(ap):
            bad.append((path, recorded, None))
            unreadable = True
            continue
        actual = sha256_file(ap)
        if actual != recorded:
            bad.append((path, recorded, actual))
    if unreadable:
        return "UNREADABLE", bad
    return ("DIFFERS" if bad else "MATCHES"), bad
